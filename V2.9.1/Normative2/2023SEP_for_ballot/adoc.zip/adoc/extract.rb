require_relative 'extract/utils'
require_relative 'extract/v2'
require_relative 'extract/datatypes'
require_relative 'extract/events'
require_relative 'extract/segments'
module V2AsciiDoc
  module_function

  def extract_chapters
    chapters.each { |ch| extract_ch(ch) }
  end
  
  def extract_ch(ch)
    files = Dir["#{adoc_dir(ch)}/*"]
    files.each do |adoc_file|
      lines = File.readlines(adoc_file)
      section = File.basename(adoc_file).sub('.adoc', '')
      section_obj = V2AsciiDoc::Section.new(section, Text.new(lines))
      # puts Rainbow(section).magenta
      
      # Events
      is_event = false
      has_message_struct = false

      if lines.any? { |str| str =~ /==+.*\(\s*Event/ }
        # puts Rainbow(lines.first).green
        is_event = true
      elsif lines.any? { |str| str =~ /4\.4\.1(1|3)\.(1|2)\s/ || str =~ /4\.4\.9\.(1|2)\s/ }
        puts Rainbow(lines.first.chomp).coral + ' SPECIAL'
        is_event = true
      end

      if lines.any? { |l| is_message_structure_table_header?(l) }
        # puts Rainbow(lines.first).yellow
        has_message_struct = true
      end
      
      if is_event && has_message_struct
        extract_events(lines, section)
      end
      
      if is_event && !has_message_struct
        # FIXME we still need to capture this and create a withdrawn Event
        if lines.find { |l| l =~ /withdrawn/i }
          extract_withdrawn_event(lines, section)
        elsif lines.first =~ /4\.4\.(9|11|13)\s/
          # message structs are in subsections...
        else
          puts Rainbow("Alert! No msg struct! #{section}").red + ' ' + lines.first
        end
      end
      
      if section == '10.3'
        extract_10_3(lines)
      end
      
      
# next
      # Segments
      is_segment  = false
      has_seg_def = false
      if lines.any? { |l| l.strip =~ /==+.*\s*Segment$/ }
        # puts Rainbow(lines.first).green
        is_segment = true
      end
      if lines.any? { |l| is_segment_table_header?(l) }
        # puts Rainbow(lines.first).yellow
        has_seg_def = true
      end
      if is_segment && !has_seg_def
        # FIXME we still need to capture this and create a withdrawn Segment.  I don't even know if there are any of these....
        next if lines.find { |l| l =~ /withdrawn as of/ }
        puts Rainbow("Alert! No seg def! #{section}").red# + ' ' + lines.first
        
        lines.each { |l| puts Rainbow(l).lightskyblue }
      end
      if is_segment && has_seg_def
        extract_segment(lines, section)
      end
      
    end
  end

  def extract
    # extract_ch('2') # Control.  Rob is rewriting it anyway
    
    # extract_datatypes
    # return
    # extract_ch('1')
    
    # extract_ch('2A')

    # extract_ch('3')
    # extract_ch('4')
    extract_ch('4A')
    return
    extract_ch('5')
    extract_ch('6')
    extract_ch('7')
    extract_ch('8')
    extract_ch('9')
    extract_ch('10')
    extract_ch('11')
    extract_ch('12')
    extract_ch('13')
    extract_ch('14')
    extract_ch('15')
    extract_ch('16')
    extract_ch('17')
  end
  
  def process_table(lines, section, opts = {})
    # puts lines; puts Rainbow('----------------------').orange
    if is_message_structure_table_header?(lines.first)
      lines.shift
      [:message_structure, process_msg_structure_table(lines, section, opts)]
    elsif lines.first =~ ack_chor_table_regex
      lines.shift      
      [:ack_chor, process_ack_chor_table(lines, section, opts)]
    elsif is_segment_table_header?(lines.first)
      [:segment_definition, process_segment_table(lines, section, opts)]
    else
      puts Rainbow("#{section} has another kind of table.").magenta + " #{lines.first}"
      [:other, lines]
    end
  end
  
  def split_row(l)
    row = l.split('|').map(&:strip).map do |v|
      if v =~ /file:/
        v.gsub(/file.+\[/, '').sub(/\]$/, '')
      else
        v
      end
    end 
    row.shift if row.first == ''
    row
  end
  
  def subsection_files(section)
    ch = section.slice(/^\d+A?/)
    files = Dir["#{adoc_dir(ch)}/*.adoc"].select { |f| f =~ /#{section}/ }
  end
  
  def report
    puts "DATATYPES #{v2.datatypes.size}"
    # pp v2.datatypes
    # puts
    puts "FIELDS #{v2.fields.size}"
    # pp v2.message_structures
    # puts
    puts "DATA ELEMENTS #{v2.data_elements.size}"
    # pp v2.message_structures
    # puts
    puts "SEGMENTS #{v2.segments.size}"
    # pp v2.segments
    # puts
    puts "EVENTS #{v2.events.size}"
    # pp v2.events
    # puts
    puts "MSG STRUCTS #{v2.message_structures.size}"
    # pp v2.message_structures
    # puts
    puts "SECTIONS #{v2.sections.size}"
    # pp v2.sections
    # puts
  end
  
end  
# V2AsciiDoc.extract_datatypes
V2AsciiDoc.extract
# V2AsciiDoc.extract_ch('3')
V2AsciiDoc.report
