module V2AsciiDoc
  module_function

  def message_structure_table_regex
    /\s*\|\s*Segments\s*\|\s*Descriptions?\s*\|\s*Status\s*\|\s*Chapter\s*/
  end
  
  def is_message_structure_table_header?(str)
    x = remove_empty_cells(str) 
    # puts x
    x =~ message_structure_table_regex
  end
  
  def remove_empty_cells(str)
    str.gsub(/\|\s*(?=\|)/, '')
  end
  
  def ack_chor_table_regex
    /\s*\|\s*Acknowledge?ment Choreography\s*\|/
  end

  def extract_withdrawn_event(lines, section)
    l1 = lines.first
    code = l1.slice(/(?<=\(Event).+(?=\))/).strip
    raise "No code for withdrawn event #{lines.first}" unless code
    name = l1.slice(/(?<=(-|–)).+(?=\(Event)/)&.strip
    raise "No name for withdrawn event #{lines.first}" unless name
    event = V2AsciiDoc::Event.new(code, name)
    V2AsciiDoc.v2.events[code] = event
    event.section = section
    event.adoc_source = lines
    event.text = Text.new(lines[1..-1])
  end
  
  # FIXME
  def extract_10_3(original_lines)
    tables = []
    text_buffer  = []
    table_buffer = []
    table = false
    table_mark = 0
    lines.shift if lines.first.strip == ''
    lines.each_with_index do |l, i|
      if l =~ /\[width="\d+%",cols=/ # a table is next
        # FIXME should we retain the table formatting directive?
        table = true
      else
        if l.strip =~ /(SRM)\^(S01-S11)\^(SRM_S01): Schedule Request Message/
          msg_code        = 'SRM'
          msg_struct_code = 'SRM_S01'
        elsif l.strip =~ /(SRR)\^(S01-S11)\^(SRR_S01): Scheduled Request Response/
          msg_code        = 'SRR'
          msg_struct_code = 'SRR_S01'
        end

        if table
          if l.strip =~ /\|==+/
            table_mark += 1
            if table_mark > 1
              table = false
              table_mark = 0
              tables << table_buffer.dup
              table_buffer = []
            end
            next
          end
          table_buffer << l
        end
      end
    end
    tables.each_with_index do |tbl, i|
      if i < 2
        process_table(tbl, nil, :msg_struct_code => 'SRM_S01')
      else
        process_table(tbl, nil, :msg_struct_code => 'SRR_S01')
      end
    end
    message_codes  = []
    counter = 0
    # 11.times do
    #   counter += 1; x = counter.to_s.rjust(2, '0'); message_codes << "S" + x
    # end

    message_codes.each do |mc|
      event = V2AsciiDoc::Event.new(code, nil)
    end



    # V2AsciiDoc.v2.events[code] = event
    # event.section = section
    # event.adoc_source = lines

  end

  def extract_events(lines, section, opts = {})
    l1 = lines[0]
    # puts l1
    codes = l1.slice(/(?<=\(Events).+(?=\))/)&.strip
    codes ||= l1.slice(/(?<=\(Event)\s+[A-Z0-9]{3}(-|–)[A-Z0-9]{3}\s*(?=\))/)&.strip
    if codes
      if codes =~ /[A-Z0-9]{3}(-|–)[A-Z0-9]{3}/
        puts Rainbow("CODES").orange + " #{codes}"
        if codes == 'M06-M07'
          _extract_event(lines, section, 'M06'); _extract_event(lines, section, 'M07')
        elsif codes == 'C01-C08'
          (1..8).each { |r| _extract_event(lines, section, 'C0' + r.to_s) }
        elsif codes == 'C09-C12'
          _extract_event(lines, section, 'C09')
          (10..12).each { |r| _extract_event(lines, section, 'C' + r.to_s) }
        end
      elsif codes.split(/,\s*/).size > 1
        codes = codes.split(/,\s*/)
        codes.each { |c|  _extract_event(lines, section, c)}
      elsif codes.split(/\s+and\s+/).size == 2
        codes = codes.split(/\s+and\s+/)
        extract_query_response(lines, section, codes) # FIXME implement
      else
        puts Rainbow("CODES! #{codes.inspect}").red
      end
    else
      code = l1.slice(/(?<=\(Event).+(?=\))/)&.strip
      if code
        _extract_event(lines, section, code)
      else
        if l1 =~ /4\.4\.1(1|3)\.(1|2)/
          _extract_event(lines, section, 'O36', :name => 'Laboratory order response message to a single container of a specimen OML - Patient Segments Required') if l1 =~ /4\.4\.11\.1/
          _extract_event(lines, section, 'O55', :name => 'Laboratory order response message to a single container of a specimen OML - Patient Segments Optional') if l1 =~ /4\.4\.11\.2/
          _extract_event(lines, section, 'O40', :name => 'Specimen shipment centric laboratory order response message to specimen shipment OML - Patient Segments Required') if l1 =~ /4\.4\.13\.1/
          _extract_event(lines, section, 'O56', :name => 'Specimen shipment centric laboratory order response message to specimen shipment OML - Patient Segments Optional') if l1 =~ /4\.4\.13\.2/
        elsif l1 =~ /4\.4\.9\.(1|2)/
          _extract_event(lines, section, 'O34', :name => 'Laboratory order response message to a multiple order related to single specimen OML - Patient Segments Required') if l1 =~ /4\.4\.9\.1/
          _extract_event(lines, section, 'O54', :name => 'Laboratory order response message to a multiple order related to single specimen OML - Patient Segments Optional') if l1 =~ /4\.4\.9\.2/
        else
          raise l1
        end
      end
    end
  end
  
  def _extract_event(original_lines, section, code, opts = {})
    lines = original_lines.dup
    l1 = lines.shift
    pair = l1.sub(/^\s*=+\s*\d+\.\d+.\d+\s*/, '').sub(/(-|–).+$/, '').strip
    name = opts[:name]
    # puts Rainbow(name).lime if name
    name ||= l1.slice(/(?<=(-|–)).+(?=\(Event)/)&.strip
    name ||= l1.slice(/Order Status Update (?=\(Event O51)/)&.strip
    puts Rainbow("#{section} Event #{code}").cyan
    puts Rainbow("ALERT!").orange + " No name in first line of event section: #{l1}" unless name
    # puts pair
    # puts Rainbow(name).orange
    # puts code;return
# return #unless code == 'A01'
    # puts Rainbow(section).green
    
    event = V2AsciiDoc::Event.new(code, name)
    V2AsciiDoc.v2.events[code] = event
    event.section = section
    event.adoc_source = lines
    # lines.each { |l| puts Rainbow(l).yellow }
    # puts Rainbow('-'*33).orange
    text_buffer  = []
    table_buffer = []
    table = false
    table_mark = 0
    lines.shift if lines.first.strip == ''
    msg_struct_code = nil
    msg_code        = nil
    event_code      = nil
    tables = {}
    lines.each_with_index do |l, i|
      if l =~ /\[width="\d+%",cols=/ # a table is next
        # should we retain the table formatting directive? no....
        table = true
      else
        if l =~ /([A-Z0-9]{3})\^(#{code})\^([A-Z0-9]{3}_[A-Z0-9]{3}):\s+(.*)\s*(Message|Description)?/
          # puts Rainbow(l).magenta
          # if l =~ /([A-Z0-9]{3})\^(#{code})\^([A-Z0-9]{3}_[A-Z0-9]{3}):\s+(.*)\s*(Message|Description)?/
          msg_code        = $1
          event_code      = $2
          msg_struct_code = $3
          puts Rainbow("#{code} != #{event_code}").red unless code == event_code
        elsif l.strip =~ /([A-Z0-9]{3})\^(#{code})\^([A-Z0-9]{3}):\s+.*Acknowledge?ment$/
          # puts Rainbow(l).lawngreen
          msg_code        = $1
          event_code      = $2
          msg_struct_code = $3
          puts Rainbow("#{code} != #{event_code}").red unless code == event_code
        elsif l =~ /([A-Z0-9]{3})\^(.+)\^([A-Z0-9]{3}_[A-Z0-9]{3}):\s+(.*)\s*(Message|Description)?/
          # puts Rainbow($1 + '^' + $2 + '^' + $3).lawngreen
          puts Rainbow(l).coral
          msg_code        = $1
          event_code      = $2
          msg_struct_code = $3
          # puts Rainbow("#{code} != #{event_code}").red unless code == event_code
          event_code = code
        elsif l =~ /([A-Z0-9]{3})\^(.+)\^([A-Z0-9]{3}_[A-Zn0-9]{3}):\s+(.*)\s*(Message|Description)?/
          puts Rainbow(l).fuchsia
          msg_code        = $1
          event_code      = $2
          msg_struct_code = $3
          # puts Rainbow("#{code} != #{event_code}").red unless code == event_code
          event_code = code
        else
          # puts Rainbow(l).yellow
        end
        
        if table
          if l.strip =~ /\|==+/
            table_mark += 1
            if table_mark > 1
              table = false
              table_mark = 0
            end
            next
          end
          table_buffer << l
        else
          if table_buffer.any?
            # puts table_buffer
            ttype = "Unknown"
            if is_message_structure_table_header?(table_buffer.first)
              ttype = Rainbow("MSG_STRUCT" ).gold
              tables[msg_struct_code] = table_buffer.dup
              puts "#{ttype} -- #{msg_code}^#{event_code}^#{msg_struct_code}" #: #{table_buffer.first}"
              table_buffer = []
              text_buffer << "\include::message_structure_table_#{msg_code}^#{event_code}^#{msg_struct_code}"
              next
            end
            if table_buffer.first =~ ack_chor_table_regex
              ttype = Rainbow("ACK_CHOR  " ).gold
              tables[msg_struct_code] = table_buffer.dup
              puts "#{ttype} -- #{msg_code}^#{event_code}^#{msg_struct_code}" #: #{table_buffer.first}"
              table_buffer = []
              text_buffer << "\include::ack_chor_table_#{msg_code}^#{event_code}^#{msg_struct_code}"
              next
            end
            if ttype == "Unknown"
              puts Rainbow(ttype + ' Table Type: ').orange + table_buffer.first.chomp
              text_buffer += table_buffer
              table_buffer = []
              next
            end
            
            # table_type, processed_table = process_table(table_buffer, section, :msg_struct_code => msg_struct_code)
            # if table_type == :message_structure
            #   text_buffer << '\include::message_structure_table'
            # elsif table_type == :ack_chor
            #   text_buffer << '\include::ack_chor_table'
            # elsif table_type == :other
            #   text_buffer += processed_table
            # else
            #   puts processed_table
            #   raise "Wrong kind of table!! -- #{table_type}"
            # end
            # table_buffer = []
          end
          text_buffer << l
        end
      end
    end
    event.text = Text.new(text_buffer)
    tables.each do |ms, tbl|
      table_type, processed_table = process_table(tbl, section, :msg_struct_code => ms)
      if table_type == :message_structure
      elsif table_type == :ack_chor
      elsif table_type == :other
      else
        puts processed_table
        raise "Wrong kind of table!! -- #{table_type}"
      end
    end
  end
  
  # FIXME
  def extract_query_response(lines, section, codes)
    
  end
  
  def clean_msg_structure_cell(str)
    return str unless str =~ /file|link/
    str = remove_underline(str)
    linkless = remove_link_link(remove_file_link(str))
  end
  
  def remove_underline(str)
    return str unless str =~ /underline/
    str = str.gsub(/\[.underline\]#(.+?)#/, '\1')
  end
  
  def remove_file_link(str)
    _remove_link(str, :file)
  end
  
  def remove_link_link(str)
    _remove_link(str, :link)
  end
  
  def _remove_link(str, type)
    return str unless str =~ /#{type}/
    # puts Rainbow(str).blue
    str =~ /(#{type}:.+?)(?=\[)/
    link = $1
    # puts Rainbow(link).cyan #if link =~ /\[|\]/ # rarely happens
    reggie = /#{link}\[(.+?)\]/
    # puts reggie.inspect
    mm = reggie.match(str)
    # pp mm
    correct = $1
    # puts Rainbow(correct).coral
    ret = str.sub(/#{link}\[(.+?)\]/, '\1')
    # puts Rainbow(ret).coral
    ret
  end
  
  def extract_footnote_from_seg(seg)
    return [seg, nil] unless seg =~ /footnote:/
    fn = seg.slice(/footnote:\[.+\]/)
    [seg.sub(fn, ''), fn.sub('footnote:', '').sub(/^\[/, '').sub(/\]$/, '')]
  end
  
  def process_msg_structure_table(lines, section, opts)
    # puts lines unless opts[:msg_struct_code]
    msg_structure = V2AsciiDoc::MessageStructure.new(opts[:msg_struct_code])
    puts Rainbow("Struct ").green + msg_structure.code
    # puts Rainbow(section + " #{msg_structure.code}").green
    # puts lines[0..4]
    V2AsciiDoc.v2.message_structures[msg_structure.code] = msg_structure
    current_container = msg_structure
    lines.each do |l|
      l = l[1..-1] if l[0] == '|'
      row = remove_empty_cells(l).split('|').map(&:strip).map { |c| c.gsub(/\\/, '') }
      # puts row.inspect
      seg, desc, status, chapter = row
      # puts Rainbow(seg).yellow
      seg, footnote = extract_footnote_from_seg(seg)
      seg  = clean_msg_structure_cell(seg)
      desc = clean_msg_structure_cell(desc)
      status = clean_msg_structure_cell(status)
      chapter = clean_msg_structure_cell(chapter)
      seg = seg.gsub(/\s/, '').gsub('{[', '{').gsub(']}', '}').gsub('[[', '[').gsub(']]', ']')
      # puts Rainbow(seg).gold
      repeating = seg[0..1] =~ /\{/ ? true : false
      optional  = seg[0..1] =~ /\[/ ? true : false
# FIXME choice segments detect!
      if seg =~ /([A-Z][A-Z][A-Z0-9])/ || seg =~ /(\.\.\.)/
        code = $1
        segment = V2AsciiDoc::Segment.new(desc)
        if footnote
          # puts Rainbow(footnote).blue
          segment.footnote = footnote
        end
        segment.type     = code
        segment.optional = optional
        segment.repeat   = repeating
        segment.container = current_container
        current_container.segments << segment
        # puts "#{code}#{optional ? ' optional' : nil} #{repeating ? ' repeat' : nil} #{seg}"
      else
        # Then it is the start or end of a sequence (or choice??)
        if seg =~ /\[|\{/
          # puts "start sequence #{optional ? ' optional' : nil} #{repeating ? ' repeat' : nil} #{seg}"
          seg_seq = V2AsciiDoc::SegmentSequence.new(desc.strip.sub(/^\s*-*\s*/, '').sub(/\s*(begin|end)$/, ''))
          seg_seq.optional = optional
          seg_seq.repeat   = repeating
          current_container.segments << seg_seq
          seg_seq.container = current_container
          current_container = seg_seq
        elsif seg =~ /\]|\}/
          # puts "end sequence #{seg}"
          current_container = current_container.container
        else
          puts Rainbow("POOP -- #{seg}").red
        end
      end
    end
    # puts Rainbow('-'*33).orange
  end
  
  def process_ack_chor_table(lines, section, opts)
  end
end  
