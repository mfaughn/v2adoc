require_relative 'utils'
require_relative 'v2'
module V2AsciiDoc
  module_function
  
  def extract_datatypes
    # dir = File.join(adoc_dir, '2A')
    files = Dir["#{adoc_dir('2A')}/*"]
    # first get all datatype table sections
    files.each do |adoc_file|
      lines = File.readlines(adoc_file)
      base_section = adoc_file.sub('.adoc', '')
      if lines.any? { |str| str =~ /\|===/ } 
        if lines.first =~ /===\s+2A\.\d+\.\d+\s+/
          x = lines.first.strip.gsub(/^=+\s*/, '').sub(/^2A\.\d+\.\d+/, '').strip
          code, title = x.split(/-|–/).map(&:strip)
          dt = V2AsciiDoc::Datatype.new(code, title)
          V2AsciiDoc.v2.datatypes[code] = dt
          puts Rainbow(code).green + ' ' + File.basename(base_section)
          dt.adoc_source = lines
          
          first_component_i = (lines.index  { |l| l =~ /\|\s*SEQ\s*\|\s*LEN\s*\|/ }) + 1
          table = []
          after_table_i = nil
          lines[first_component_i..-1].each_with_index do |l, i|
            # puts Rainbow(l).yellow
            if l =~ /\|===/
              after_table_i = i + 1
              break
            end
            row = split_row(l)
            table << row if row.first =~ /^\d+\.?$/
          end
          table.each do |row|
            dt.components << V2AsciiDoc::Component.new(row)
          end
          # pp dt.components
          # puts Rainbow(code).green + ' ' + title
          subfiles = files.select { |f| f =~ /#{base_section}\.\d/ }.sort_by { |f| f.sub(base_section + '.', '').sub('.adoc', '').to_i }.reject { |f| f =~ /\.0\.adoc/ }
          subfiles.each do |sf|
            seq = File.basename(sf).sub('.adoc', '').split('.').last
            comp = dt.components.find { |c| c.seq == seq }
            comp_section = File.basename(sf).sub('.adoc', '')
            # puts Rainbow(comp_section).cyan
            comp.section = comp_section
            sf_lines = File.readlines(sf)
            comp.adoc_source = sf_lines
            comp.text = Text.new(sf_lines[1..-1])
            l1 = sf_lines.first.sub(/^=+/, '').strip
            unless l1 =~ /#{comp.datatype}/ && l1 =~ /#{comp.section}/ && l1 =~ /#{comp.name}/i
              puts "#{comp.section} #{comp.name} (#{comp.datatype})"
              puts Rainbow(l1).yellow
            end
          end
          
          dt.text = Text.new(lines[(after_table_i + first_component_i)..-1])
          # puts dt.text
        end
        
      end
    end
  end

end
