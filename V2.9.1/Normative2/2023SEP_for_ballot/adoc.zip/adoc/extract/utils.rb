require 'fileutils'
require 'open3'
require 'rainbow'
module V2AsciiDoc
  module_function
  
  def adoc_dir(ch = nil)
    dir = File.expand_path(ch ? File.join(__dir__, '..', ch) : __dir__)
    raise "NOPE: #{dir}" unless File.exist?(dir)
    dir
  end
  
  def test_dir
    File.expand_path('../test', __dir__)
  end
  
  def html_dir
    @html_dir ||= File.expand_path('../../html', __dir__)
  end
  
  def html_ch_dir(ch)
    ch ? File.join(html_dir, ch) : html_dir
  end
  
  def chapters
    %w{1 2A 3 4 4A 5 6 7 8 9 10 11 12 13 14 15 16 17}
  end
end
