# require_relative 'utils'
require 'singleton'
# require 'sequel'

# DB = Sequel.sqlite # in-memory DB
# Sequel::Model.plugin :json_serializer
#
# dbtables = [
#   :sections => [[String, :adoc], [String, :number]],
#   :events   => [[String, :adoc_source], [String, :text], [String, :code], [String, :status]],
#
# ]
#
# DB.create_table :sections do
#   primary_key :id
#   String :adoc
#   String :number
# end
#
# DB.create_table
# end


module V2AsciiDoc
  class V2
    include Singleton
    attr_reader :sections, :datatypes, :segments, :messages, :message_structures, :events, :data_elements, :fields
    def initialize
      @sections           = {}
      @datatypes          = {}
      @segments           = {}
      # @messages           = []
      @events             = {}
      @data_elements      = {}
      @message_structures = {}
      @fields             = {}
    end
  end
  
  def self.v2
    V2.instance
  end
end


module V2AsciiDoc
  class Section# < Sequel::Model
    def initialize(id, adoc)
      @id   = id
      @adoc = adoc
    end
  end
  
  class Text
    attr_accessor :lines
    def initialize(lines)
      @lines = lines
    end
  end


  class V2Obj# < Sequel::Model
    attr_accessor :section, :text, :adoc_source
  end

  class Event < V2Obj
    attr_accessor :name, :code, :message, :status, :trigger
    def initialize(code, name)
      @code = code
      @name = name
      message = Message.new
      message.trigger_for = self
      @message = message
    end
  end

  class MessageType < V2Obj
    attr_accessor :name, :code, :messages
  end

  class Message < V2Obj
    attr_accessor :message_type, :message_structure, :responses, :ack, :responses_for, :ack_for, :trigger_for
  end

  class MessageStructure < V2Obj
    attr_accessor :messages, :segments, :code, :withdrawn
    def initialize(code)
      @code     = code
      @segments = []
      @messages = []
    end
  end

  class AbstractSegment < V2Obj
    attr_accessor :container, :name, :repeat, :optional, :status, :footnote
  end

  class Segment < AbstractSegment
    attr_accessor :type
    def initialize(name)
      @name = name
    end
  end

  class SegmentSequence < AbstractSegment
    attr_accessor :segments
    def initialize(name)
      @name = name
      @segments = []
    end
  end

  class SegmentChoice < AbstractSegment
    attr_accessor :segments
    def initialize(name)
      @name = name
      @segments = []
    end
  end

  class ExampleSegment < AbstractSegment
    def initialize(name)
      @name = name
    end
  end

  class SegmentDefinition < V2Obj
    attr_accessor :fields, :name, :withdrawn, :code
    def initialize(code, name)
      @fields = []
      @code = code
      @name = name
    end
  end

  class Field < V2Obj
    attr_accessor :seq, :data_element, :must_support, :min_card, :max_card, :opt, :flags, :repetition, :addendum_type, :definition_text, :description
    def initialize(seq)
      @seq = seq
    end
  end

  class DataElement < V2Obj
    attr_accessor :name, :item_number, :min_length, :max_length, :c_length, :may_truncate, :datatype_varies, :datatype, :definition_text, :table
    def initialize(item_number, min_length, max_length, c_length, datatype)
      @item_number = item_number
      @min_length  = min_length
      @max_length  = max_length
      @c_length    = c_length
      @datatype    = datatype
    end
  end

  class DefinitionText < V2Obj
    attr_accessor :definition, :description
  end

  class Datatype < V2Obj
    attr_accessor :name, :code, :components, :primitive
    def initialize(code, name)
      @code = code
      @name = name
      @components = []
      @primitive = nil
    end
  end

  class Component < V2Obj
    attr_accessor :seq, :len, :clen, :datatype, :opt, :tbl, :name, :comments, :sec_ref, :parent
    def initialize(row)
      row = row.map { |x| x.strip == '' ? nil : x }
      @seq, @len, @clen, @datatype, @opt, @tbl, @name, @comments, @sec_ref = row
    end
  end
end
